﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asserver
{
    class Employee
    {

        public string Name { get; set; }
       // public int salary { get; set; }
        public string Department { get; set; }
        public bool IsMale { get; set; }
        public string Address { get; set; }


    
    public  Employee(string name, string department, bool male,string address)
    {
            Name = name;
         //   this.salary = salary;
            Department = department;
            IsMale = male;
            Address = address;




    }
        public Employee (byte [] data)
        {
          
         //   IsMale = BitConverter.ToBoolean(data, 0);
         // //  int length = BitConverter.ToInt32(data, 1);
         //   Name = Encoding.ASCII.GetString(data, 2);
            

           
         ////   Age = BitConverter.ToUInt16(data, 1);
            int nameLength = BitConverter.ToInt32(data, 1);
            Name = Encoding.ASCII.GetString(data, 5, nameLength);

             int len = BitConverter.ToInt32(data, 6);

            Department = Encoding.ASCII.GetString(data,10 , len);
        //    salary = BitConverter.ToInt16(data, 4);
            int l = BitConverter.ToInt32(data, 11);

            Address = BitConverter.ToString(data, 14, l);
           
           





        }


    }
}
