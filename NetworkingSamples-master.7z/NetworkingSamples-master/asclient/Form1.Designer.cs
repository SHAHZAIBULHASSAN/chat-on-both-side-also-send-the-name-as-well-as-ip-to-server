﻿
namespace asclient
{
    partial class Client
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textname = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.Name = new System.Windows.Forms.Label();
            this.Salary = new System.Windows.Forms.Label();
            this.Department = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.Label();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.textSalary = new System.Windows.Forms.TextBox();
            this.textaddress = new System.Windows.Forms.TextBox();
            this.btnsend = new System.Windows.Forms.Button();
            this.btnconnect = new System.Windows.Forms.Button();
            this.IP = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textname
            // 
            this.textname.Location = new System.Drawing.Point(411, 65);
            this.textname.Multiline = true;
            this.textname.Name = "textname";
            this.textname.Size = new System.Drawing.Size(100, 23);
            this.textname.TabIndex = 0;
            this.textname.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(411, 107);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(60, 19);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "IsMale";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // Name
            // 
            this.Name.AutoSize = true;
            this.Name.Location = new System.Drawing.Point(296, 72);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(50, 15);
            this.Name.TabIndex = 2;
            this.Name.Text = "lblname";
            // 
            // Salary
            // 
            this.Salary.AutoSize = true;
            this.Salary.Location = new System.Drawing.Point(296, 241);
            this.Salary.Name = "Salary";
            this.Salary.Size = new System.Drawing.Size(38, 15);
            this.Salary.TabIndex = 3;
            this.Salary.Text = "Salary";
            // 
            // Department
            // 
            this.Department.AutoSize = true;
            this.Department.Location = new System.Drawing.Point(296, 186);
            this.Department.Name = "Department";
            this.Department.Size = new System.Drawing.Size(70, 15);
            this.Department.TabIndex = 4;
            this.Department.Text = "Department";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(296, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "Gender";
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.Location = new System.Drawing.Point(296, 299);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(49, 15);
            this.Address.TabIndex = 6;
            this.Address.Text = "Address";
            // 
            // txtDepartment
            // 
            this.txtDepartment.Location = new System.Drawing.Point(411, 178);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(100, 23);
            this.txtDepartment.TabIndex = 7;
            // 
            // textSalary
            // 
            this.textSalary.Location = new System.Drawing.Point(411, 233);
            this.textSalary.Name = "textSalary";
            this.textSalary.Size = new System.Drawing.Size(100, 23);
            this.textSalary.TabIndex = 8;
            this.textSalary.TextChanged += new System.EventHandler(this.textSalary_TextChanged);
            // 
            // textaddress
            // 
            this.textaddress.Location = new System.Drawing.Point(411, 299);
            this.textaddress.Name = "textaddress";
            this.textaddress.Size = new System.Drawing.Size(100, 23);
            this.textaddress.TabIndex = 9;
            // 
            // btnsend
            // 
            this.btnsend.Location = new System.Drawing.Point(296, 363);
            this.btnsend.Name = "btnsend";
            this.btnsend.Size = new System.Drawing.Size(75, 23);
            this.btnsend.TabIndex = 10;
            this.btnsend.Text = "Send";
            this.btnsend.UseVisualStyleBackColor = true;
            this.btnsend.Click += new System.EventHandler(this.btnsend_Click);
            // 
            // btnconnect
            // 
            this.btnconnect.Location = new System.Drawing.Point(36, 177);
            this.btnconnect.Name = "btnconnect";
            this.btnconnect.Size = new System.Drawing.Size(75, 23);
            this.btnconnect.TabIndex = 11;
            this.btnconnect.Text = "Connect";
            this.btnconnect.UseVisualStyleBackColor = true;
            this.btnconnect.Click += new System.EventHandler(this.btnconnect_Click);
            // 
            // IP
            // 
            this.IP.AutoSize = true;
            this.IP.Location = new System.Drawing.Point(48, 83);
            this.IP.Name = "IP";
            this.IP.Size = new System.Drawing.Size(37, 15);
            this.IP.TabIndex = 12;
            this.IP.Text = "textIp";
            // 
            // Client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.IP);
            this.Controls.Add(this.btnconnect);
            this.Controls.Add(this.btnsend);
            this.Controls.Add(this.textaddress);
            this.Controls.Add(this.textSalary);
            this.Controls.Add(this.txtDepartment);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Department);
            this.Controls.Add(this.Salary);
            this.Controls.Add(this.Name);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.textname);
            //this.Name = "Client";
            this.Text = "Clientside";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textname;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label Name;
        private System.Windows.Forms.Label Salary;
        private System.Windows.Forms.Label Department;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.TextBox txtDepartment;
        private System.Windows.Forms.TextBox textSalary;
        private System.Windows.Forms.TextBox textaddress;
        private System.Windows.Forms.Button btnsend;
        private System.Windows.Forms.Button btnconnect;
        private System.Windows.Forms.Label IP;
    }
}

