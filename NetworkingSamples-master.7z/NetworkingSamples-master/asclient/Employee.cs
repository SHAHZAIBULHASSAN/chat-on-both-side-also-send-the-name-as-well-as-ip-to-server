﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asclient
{
    class Employee
    {
        public string Name { get; set; }
       // public ushort salary { get; set; }
        public string Department { get; set; }
        public bool IsMale { get; set; }
        public string Address { get; set; }



        public Employee(string name, string department, bool male, string address)
        {
            Name = name;
           // this.salary = salary;
            Department = department;
            IsMale = male;
            Address = address;




        }

        internal byte[] ToByteArray()
        {
            List<byte> by = new List<byte>();
            by.AddRange(BitConverter.GetBytes(IsMale));
            by.AddRange(BitConverter.GetBytes(Name.Length));
            by.AddRange(Encoding.ASCII.GetBytes(Name));
            List<byte> byteList = new List<byte>();
            byteList.AddRange(BitConverter.GetBytes(IsMale));
           // byteList.AddRange(BitConverter.GetBytes(Name));
            byteList.AddRange(BitConverter.GetBytes(Name.Length));
            byteList.AddRange(Encoding.ASCII.GetBytes(Name));
            byteList.AddRange(BitConverter.GetBytes(Department.Length));
            byteList.AddRange(Encoding.ASCII.GetBytes(Department));
            byteList.AddRange(BitConverter.GetBytes(Address.Length));
            byteList.AddRange(Encoding.ASCII.GetBytes(Address));

            return byteList.ToArray();
        }
    }
}
