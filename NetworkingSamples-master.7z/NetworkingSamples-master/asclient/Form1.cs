﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace asclient
{
    public partial class Client : Form
    {
        private Socket clientSocket;
        private Socket server;
        private byte[] buffer;

        public Client()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnsend_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee(textname.Text,txtDepartment.Text,checkBox1.Checked,txtDepartment.Text);
          //  PersonPackage person = new PersonPackage(checkBoxMale.Checked, (ushort)numberBoxAge.Value, textBoxEmployee.Text, textBoxAddress.Text);
            byte[] buffer = emp.ToByteArray();
            clientSocket.BeginSend(buffer, 0, buffer.Length, SocketFlags.None, SendCallback, null);
        }

        private void SendCallback(IAsyncResult ar)
        {
             sck = clientSocket.EndSend(ar);
        }

        private void btnconnect_Click(object sender, EventArgs e)
        {
            try
            {
                clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                // Connect to the specified host.
                IPHostEntry host;
                IPAddress LocalIP = null;
                host = Dns.GetHostEntry(Dns.GetHostName());
                foreach (IPAddress ip in host.AddressList)
                {
                    if (ip.AddressFamily.ToString() == "InterNetwork")

                    {
                        LocalIP = ip;

                        string str = LocalIP.ToString();
                        // IPAddress u = str.;

                        //  MessageBox.Show(str);
                        IP.Text = str;
                        //IPEndPoint a=CreateIPEndPoint(str);
                    }
                }
                IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(IP.Text), 3333);
                clientSocket.BeginConnect(endPoint, ConnectCallback, null);

            }
            catch  (Exception ex)
            {

            }
            }

        private void ConnectCallback(IAsyncResult ar)
        {
            clientSocket.EndConnect(ar);


           // c.EndConnect(AR);
         //   UpdateControlStates(true);
            buffer = new byte[clientSocket.ReceiveBufferSize];
            clientSocket.BeginSend(buffer, 0, buffer.Length, SocketFlags.None, SendCallback, null);

        }

        private void ReceiveCallback(IAsyncResult ar)
        {
            
        }

        private void textSalary_TextChanged(object sender, EventArgs e)
        {

        }
    } 
} 
    
