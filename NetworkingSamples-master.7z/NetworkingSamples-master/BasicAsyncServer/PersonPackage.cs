﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace BasicAsyncServer
{
    class PersonPackage
    {
        string a; Socket sck;
        
        public int Salary { get; set; }
        public string ab = null;
        public bool IsMale { get; set; }
        public ushort Age { get; set; }
        public string Name { get; set; }
        public string EndPoint { get; set; }


        public PersonPackage(bool male, ushort age, string name, string endpoint)
        {
            IsMale = male;
            Age = age;
            Name = name;
            EndPoint = endpoint;
          //   a = EndPoint.ToString();

            //String ipAddress = endpoint;

            //System.Net.IPAddress ipAddress = System.Net.IPAddress.Parse(ipAddress);

            //System.Net.IPEndPoint remoteEndPoint = new IPEndPoint(ipAddress, 9000);

            //EndPoint =(IPEndPoint) endpoint;
        }

        public PersonPackage(byte[] data)
        {
            IsMale = BitConverter.ToBoolean(data, 0);
            Age = BitConverter.ToUInt16(data, 1);
            int nameLength = BitConverter.ToInt32(data, 3);
            Name = Encoding.ASCII.GetString(data, 7, nameLength);
            int name = BitConverter.ToInt32(data, 8);

            // string s = ab;

            //EndPoint = end.Address;
            // string ss = System.Text.Encoding.UTF8.GetString(s, 0, s.Length);
            // EndPoint = BitConverter.get(s, 4);

            // string pp = Encoding.ASCII.GetString(da ta, 10, name);
            //    EndPoint = new IPEndPoint(IPAddress.Parse(pp), 3333);
            // EndPoint = Convert.ToString(s);
            // EndPoint=Encoding.

            //     string a = EndPoint.ToString();
            EndPoint = sck.RemoteEndPoint.ToString();
             //    EndPoint = Encoding.ASCII.GetString(data, 44, name);
          //  EndPoint = "127.0.0.1";
          //  IPEndPoint ipa = CreateIPEndPoint(a);
        //    string str=ipa.ToString();
            #region comment
            // IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(str),3333);
            //string E= endPoint.ToString();
            // byte[] bytes = Encoding.ASCII.GetBytes(E);
            // string aa=EndPoint.ToString();
            // aa = Encoding.Default.GetString(data,23,name);
            //IPAddress add = new IPAddress(new byte[] { bytes })
            ;
            // Endpoint = bytes;
            // char P = E.ToCharArray();
            //byteList.AddRange(BitConverter.GetBytes(ipa.Length));

            //EndPoint = Encoding.ASCII.GetString(bytes, 34, name) ; 
            #endregion

            //IPEndPoint CreateIPEndPoint(string )
            //{
            //    string[] ep = a.Split('.');
            //    // if (ep.Length != 1) throw new FormatException("Invalid endpoint format");
            //    IPAddress ip;
            //    if (!IPAddress.TryParse(ep[0], out ip))
            //    {
            //        throw new FormatException("Invalid ip-adress");
            //    }
            //    //int port;
            //    //if (!int.TryParse(ep[4], NumberStyles.None, NumberFormatInfo.CurrentInfo, out port))
            //    //{
            //    //    throw new FormatException("Invalid port");
            //    //}
            //    return new IPEndPoint(ip, 0);
            //}
            //#region comment
            ////string point = Encoding.UTF8.GetString(data, 15, name);
            ////EndPoint = new IPEndPoint(IPAddress.Parse(point), 3333);

            ////string a =data.ToString() ;
            ////byte[] array = Encoding.ASCII.GetBytes(a);
            ////foreach (byte i in array)
            ////{ 


            //// MessageBox.Show("{0}",i.ToString());

            ////   // Console.WriteLine("{0}==={1}", (char)i, i);

            ////}
            ////foreach (var item in collection)
            ////{

            ////}

            ////IPAddress ipv4Addr = IPAddress.Parse(data,11);
            ////Console.WriteLine(ipv4Addr.ToString());
            ////byte[] b = ipv4Addr.GetAddressBytes();
            ////ipv4Addr = new IPAddress(b);
            ////Console.WriteLine(ipv4Addr.ToString());


            ////IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(data), 3333);
            ////EndPoint = Encoding.Default.GetString(data);
            ////IPEndPoint MyIP = IPAddress.Parse((string)()).Address.ToString());
            //// IPEndPoint endPoint = new IPEndPoint(IPAddress.TryParse(data), 3333);
            ////EndPoint = Encoding.ASCII.GetString(data, 11, name);

            //////byteList.AddRange(BitConverter.GetBytes(a.Length));
            //// byteList.AddRange(Encoding.ASCII.GetBytes(a.ToString()));
            //// String MyIP = IPAddress.Parse(((IPEndPoint)EndPoint..RemoteEndPoint).Address.ToString()).ToString();
            ////string MyIP = (IPEndPoint)nameLength.ToString();
            ////   EndPoint = Convert.ToBase64String(data);
            //#endregion
        }


        /// <summary>
        ///  Serializes this package to a byte array.
        /// </summary>
        /// <remarks>
        /// Use the <see cref="Buffer"/> or <see cref="Array"/> class for better performance.
        /// </remarks>
      public  byte[] ToByteArray()
            {
                List<byte> byteList = new List<byte>();
                byteList.AddRange(BitConverter.GetBytes(IsMale));
                byteList.AddRange(BitConverter.GetBytes(Age));
                byteList.AddRange(BitConverter.GetBytes(Name.Length));
                byteList.AddRange(Encoding.ASCII.GetBytes(Name));
                string a = EndPoint.ToString();
            ab = a;
                byteList.AddRange(BitConverter.GetBytes(a.Length));
                byteList.AddRange(Encoding.ASCII.GetBytes(a.ToString().ToCharArray()));
                //byteList.AddRange(BitConverter.GetBytes(EndPoint.Length));
                //byteList.AddRange(Encoding.ASCII.GetBytes(EndPoint));
                //    byteList.AddRange(IPEndPoint());
                return byteList.ToArray();
            }
        }
    }


